import scrapy
from scrapy.pipelines.images import ImagesPipeline

class CarsemsarPipeline(ImagesPipeline):

    def get_media_requests(self, item, info):       
        count = 0
        for img_url in item['images_urls']:
            count += 1
            yield scrapy.Request(img_url, meta={'image_name': f'{item["name"]}','count': count})

    def file_path(self, request, response=None, info=None):
        return f"{request.meta['image_name']}_{request.meta['count']}.jpg" 