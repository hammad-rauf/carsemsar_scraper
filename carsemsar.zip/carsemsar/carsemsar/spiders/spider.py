from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import CarsemsarItem

class FoussierSpider(CrawlSpider):

    name = "carsemsar"

    start_urls = [
        "https://www.carsemsar.com/en/qatar"
    ]

    rules = (
        Rule(LinkExtractor(restrict_css= ".active+ li a")),
        Rule(LinkExtractor(restrict_css = ".cover-wrapper"),callback="car_page"),
    )   
    

    def car_page(self, response):

        item = CarsemsarItem()

        item["name"] = response.css(".page-title::text").extract_first()

        item["price"] = response.css(".highlight-detail .field-value::text").extract_first()

        item["contact"] = response.css(".highlight-detail .field-value::text").extract()

        if item["contact"]:
            item["contact"] = item["contact"][1].strip('\n')

        item["images_urls"] = response.css("#gallery img::attr(src)").extract()


        yield item

        #print(response.xpath('//a[contains(text(), "Next ›")]/@href').get())

        