# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

from scrapy import Field, Item


class CarsemsarItem(Item):
    
    name = Field()
    price = Field()
    contact = Field()

    images = Field()
    images_urls = Field()

    pass
